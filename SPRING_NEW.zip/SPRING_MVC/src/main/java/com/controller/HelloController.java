package com.controller;

// DISPATCHER SERVELET IN SPRING
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class HelloController{
	@RequestMapping("hello")
	public @ResponseBody String s() {
		return "Hello";
	}
	@RequestMapping("hi")
	public String s1(Model m,@RequestParam("query") String query) {
		m.addAttribute("query",query);
		return "Welcome";
	}
	@RequestMapping("temp")
	public String s0(Model m) {
		m.addAttribute("msg", "Ohayo");
		return "Temp";
	}
	@RequestMapping("login")
	public String s3() {
		return "Login";
	}
}