package com.BASIC_3;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages="com.BASIC_3")
public class MyConfig {
}
